const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3001;

// Carpeta donde se guardarán los videos
const uploadFolder = path.join(__dirname, 'videos');
if (!fs.existsSync(uploadFolder)) fs.mkdirSync(uploadFolder);

// Configuración de Multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadFolder),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Permitir CORS
app.use(cors());
app.use('/videos', express.static(uploadFolder));

// Endpoint para subir videos
app.post('/upload', upload.single('video'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No se subió ningún archivo' });
    res.json({
        url: `/videos/${req.file.filename}`,
        name: req.file.originalname,
        size: req.file.size,
        type: req.file.mimetype
    });
});

// (Opcional) Endpoint para listar videos subidos
app.get('/videos', (req, res) => {
    fs.readdir(uploadFolder, (err, files) => {
        if (err) return res.status(500).json({ error: 'No se pueden listar los videos' });
        res.json(files.map(f => ({ url: `/videos/${f}`, name: f })));
    });
});

app.listen(PORT, () => {
    console.log(`Servidor backend escuchando en http://localhost:${PORT}`);
});